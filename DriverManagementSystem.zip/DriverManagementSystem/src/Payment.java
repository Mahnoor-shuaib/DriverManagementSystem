/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Date;
import java.util.Calendar;
/**
 *
 * @author Mahnoor Shuaib
 */
public class Payment {
      private int year; 
    private int driverId;
    private String driverName;
    private String cnic;
    private String month;
    private String paymentMethod;
    private String date;
    private double amount;
    private String status;
    // private Date paymentDate;
//     public int getYear() { return year; }
//    public void setYear(int year) { this.year = year; }
//     public Payment() {
//        this.paymentDate = new Date();
//        this.year = new Date().getYear() +1900; // Default current year
//    }
//    
     public Payment() {
        // Current year nikalne ka traditional tareeka
        this.year = java.util.Calendar.getInstance().get(Calendar.YEAR);
    }
      public int getYear() { return year; }
    public void setYear(int year) { this.year = year; }
    
    
    
    public Payment(int driverId, String driverName, String cnic, String month, 
                   String paymentMethod, String date, double amount) {
        this.driverId = driverId;
        this.driverName = driverName;
        this.cnic = cnic;
        this.month = month;
        this.paymentMethod = paymentMethod;
        this.date = date;
        this.amount = amount;
        this.status = "Paid"; // Always paid
    } // Getters and Setters
    public int getDriverId() {
        return driverId;
    }

    public void setDriverId(int driverId) {
        this.driverId = driverId;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getCnic() {
        return cnic;
    }
    
    public void setCnic(String cnic) {
        this.cnic = cnic;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
     public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    
}
