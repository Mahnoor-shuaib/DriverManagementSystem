/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Stack;
/**
 *
 * @author Mahnoor Shuaib
 */
public class PaymentManager {
    public static Stack<Payment> paymentStack = new Stack<>();
    
    // Optional: Add payment method
    public static void addPayment(Payment payment) {
        paymentStack.push(payment);
    }
    
    // Optional: Get payments by driver ID
    public static Stack<Payment> getPaymentsByDriverId(int driverId) {
        Stack<Payment> result = new Stack<>();
        for (Payment payment : paymentStack) {
            if (payment.getDriverId() == driverId) {
                result.push(payment);
            }
        }
        return result;
    }
}
    

