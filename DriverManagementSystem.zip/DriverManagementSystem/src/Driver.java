/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import java.util.Date;  // Yeh line add karein
import java.util.Stack; // Stack ke liye bhi
/**
 *
 * @author Mahnoor Shuaib
 */
public class Driver {
    private String password;
    
   private static int idCounter = 1;
   private int id; 
   private String name;
   private String cnic;
   private String Contact_No;
   private String vehicle_Reg_No;
   private String License_No;
   private String Location;
  
   private String Payment_Method;
   private String status;
   private Date registrationDate;
   private boolean payment_completed;
   
   public Driver( String name, String cnic,String Contact_No, String Vehicle_Reg_No,String Lisense_No, String Location, String Payment_Method, String status, String password
   ){
       this.id =idCounter++;
       this.name= name;
       this.cnic= cnic;
       this.vehicle_Reg_No = Vehicle_Reg_No;
       this.License_No = Lisense_No;
       this.Contact_No=Contact_No;
       this.Payment_Method = Payment_Method;
       this.status = status;
       this.payment_completed= false;
       this.registrationDate= new Date();
       this.Location = Location;  
       this.password = password;
       System.out.println("New Driver Created - ID: " + this.id); // Debug ke liye
    
   };
   public boolean checkPassword(String inputPassword) {
        return this.password.equals(inputPassword);
    }
   public boolean isPaymentCompleted() { return payment_completed; }
    public void setPaymentCompleted(boolean paymentCompleted) { this.payment_completed = paymentCompleted; }
    
    public void setContact_No(String contact_No) {  // ye dekho capital/small
    this.Contact_No = contact_No;
}
    
    public void setVehicle_Reg_No(String vehicle_Reg_No) {  // ye dekho
    this.vehicle_Reg_No = vehicle_Reg_No;
}
    public void setLocation(String location) {
    this.Location = location;
}
    public int getId() { return id; }
    public String getName() { return name; }
    public String getCnic() { return cnic; }
    public String getVehicle_Reg_No() { return vehicle_Reg_No; }
    public String getContact_No() { return Contact_No; }
    public String getPayment_Method() { return Payment_Method; }
    public String getStatus() { return status; }
    public Date getRegistrationDate(){return registrationDate;}
    public void setStatus(String status) { this.status = status; }
    public String getLicense_No(){return License_No;}
    public String getLocation(){return Location;}
    public String getPaymentStatus() { return payment_completed ? "Paid" : "Pending"; } 
    public Date getregistrationDate() { return registrationDate; }
      
      public String getPassword() {
        return "********";
    }
      public boolean ispayment_Completed() { return payment_completed; }
    public void setpayment_Completed(boolean payment_Completed) { this.payment_completed = payment_Completed; }
    public void setstatus(String status) { this.status = status; }
     public void setPassword(String password) {
        this.password = password;
    }
     
    // ID counter reset method (agar zaroorat ho)
  //  public static void resetIdCounter() {
        //idCounter = 1;
//}
}
    